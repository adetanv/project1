import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'machinetest';
  objValues = {
    key1: 'felix',
    key2: 'felix@gmail.com',
    key3: '1234567890'
    }

    
  showAlert(){
    alert('Hello from Angular')
    }

  onSubmit(data) {
    console.warn(data)

   
   
}
}

